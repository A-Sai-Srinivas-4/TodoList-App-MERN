import React from "react";
import AddTodo from "../components/AddTodo";
import { TodoProvider } from "../context/TodoProvider";
import AppBar from "../components/AppBar";
import TodoList from "../components/TodoList";

const Home = () => {
  return (
    <TodoProvider>
      <div>
        <AppBar />
        <AddTodo />
        <TodoList />
      </div>
    </TodoProvider>
  );
};

export default Home;
