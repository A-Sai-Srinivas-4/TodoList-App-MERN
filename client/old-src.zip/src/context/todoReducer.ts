// Define action types
export const ADD_TODO = 'ADD_TODO';
export const REMOVE_TODO = 'REMOVE_TODO';
export const TOGGLE_TODO = 'TOGGLE_TODO';
// Explanation: ADD_TODO, REMOVE_TODO, and TOGGLE_TODO are action types

// Define the action structure
interface Action {
  type: string;
  payload: any;
}
// Explanation: type is the action type and payload is the action payload

// Define the reducer function
export const todoReducer = (state: any, action: Action) => {
  switch (action.type) {
    case ADD_TODO:
      return {
        ...state,
        todos: [...state.todos, action.payload], // Add new todo to the list
      };

    case REMOVE_TODO:
      return {
        ...state,
        todos: state.todos.filter((todo: { id: string }) => todo.id !== action.payload.id), // Remove todo by id
      };

    case TOGGLE_TODO:
      return {
        ...state,
        todos: state.todos.map((todo: { id: string; completed: boolean }) =>
          todo.id === action.payload.id
            ? { ...todo, completed: !todo.completed } // Toggle completion status
            : todo
        ),
      };

    default:
      return state;
  }
};
// Explanation: todoReducer is a function that takes the current state and action and returns the new state based on the action type
