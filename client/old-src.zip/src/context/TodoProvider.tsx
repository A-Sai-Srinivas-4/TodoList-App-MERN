import React, { ReactNode, useReducer } from "react"; // Import React and useReducer
import { TodoContext } from "./TodoContext"; // Import the context
import { todoReducer } from "./todoReducer"; // Import the reducer

interface Todo {
  id: string;
  task: string;
  completed: boolean;
}
// Explanation: Todo is a structure that holds an id, task, and completion status

// Define the initial state
const initialState = {
  todos: [] as Todo[],
};
// Explanation: todos is an array of todos

// Define the TodoProvider component
export const TodoProvider = ({ children }: { children: ReactNode }) => { // Define the props
  const [state, dispatch] = useReducer(todoReducer, initialState);

  return (
    <TodoContext.Provider value={{ state, dispatch }}>
      {children}
    </TodoContext.Provider>
  );
};
// Explanation: TodoProvider is a component that provides the TodoContext to its children
