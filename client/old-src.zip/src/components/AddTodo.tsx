import React, { useState } from "react";
import { useTodoContext } from "../context/TodoContext";
import { ADD_TODO } from "../context/todoReducer";
import { TextField, Button, Box } from "@mui/material";
import { motion } from "framer-motion";

// Motion animation variants for the container
const containerVariants = {
  hidden: { opacity: 0, y: -20 },
  visible: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 120 } },
};

const buttonVariants = {
  hover: { scale: 1.05, transition: { duration: 0.3 } },
  tap: { scale: 0.95 },
};

const AddTodo: React.FC = () => {
  const [task, setTask] = useState("");
  const { dispatch } = useTodoContext();

  const handleAddTodo = () => {
    const trimmedTask = task.trim();

    if (trimmedTask) {
      dispatch({
        type: ADD_TODO,
        payload: {
          id: Date.now().toString(),
          task: trimmedTask,
          completed: false,
        },
      });
      setTask(""); // Clear input after adding todo
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "Enter") {
      handleAddTodo();
    }
  };

  return (
    <div
      style={{
        marginTop: "20px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <Box
          component="div"
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 2,
            padding: 2,
            backgroundColor: "#f5f5f5",
            borderRadius: "8px",
            boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
            minWidth: "500px",
          }}
        >
          <TextField
            label="Add a new task"
            variant="outlined"
            value={task}
            onChange={(e) => setTask(e.target.value)}
            onKeyPress={handleKeyPress}
            fullWidth
            autoFocus
          />
          <motion.div
            variants={buttonVariants}
            whileHover="hover"
            whileTap="tap"
          >
            <Button
              variant="contained"
              color="primary"
              onClick={handleAddTodo}
              disabled={!task.trim()} // Disable button if input is empty
              fullWidth
            >
              Add Todo
            </Button>
          </motion.div>
        </Box>
      </motion.div>
    </div>
  );
};

export default AddTodo;
