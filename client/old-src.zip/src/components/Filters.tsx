import React from "react";

const Filters = () => {
  return <div>Filters</div>;
};

export default Filters;
