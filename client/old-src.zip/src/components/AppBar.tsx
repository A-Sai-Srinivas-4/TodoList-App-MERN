import React from "react";
import "../styles/Home.css";

const AppBar = () => {
  return <div className="appBar">Todo's App</div>;
};

export default AppBar;
