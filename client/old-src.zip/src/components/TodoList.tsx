import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useTodoContext } from "../context/TodoContext";
import TodoItem from "./TodoItem";
import { Box, Typography } from "@mui/material";

const TodoList: React.FC = () => {
  const { state } = useTodoContext();

  return (
    <Box sx={{ padding: 2 }}>
      <Typography
        variant="h4"
        sx={{ display: "flex", textAlign: "flex-start", marginLeft: "40px" }}
      >
        Todo's List
      </Typography>
      <div
        style={{
          marginTop: "30px",
          marginBottom: "10px",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {state.todos.length > 0 ? (
          <AnimatePresence>
            {state.todos.map((todo) => (
              <motion.div
                key={todo.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.2 }}
              >
                <TodoItem todo={todo} />
              </motion.div>
            ))}
          </AnimatePresence>
        ) : (
          <Typography variant="body1" color="text.secondary">
            No todos available. Start by adding some!
          </Typography>
        )}
      </div>
    </Box>
  );
};

export default TodoList;
