import React from "react";
import { motion } from "framer-motion";
import { useTodoContext } from "../context/TodoContext";
import { REMOVE_TODO, TOGGLE_TODO } from "../context/todoReducer";
import { IconButton } from "@mui/material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ClearIcon from "@mui/icons-material/Clear";
import DeleteIcon from "@mui/icons-material/Delete";

interface TodoItemProps {
  todo: { id: string; task: string; completed: boolean };
}

const TodoItem: React.FC<TodoItemProps> = ({ todo }) => {
  const { dispatch } = useTodoContext();

  const handleToggle = () => {
    dispatch({
      type: TOGGLE_TODO,
      payload: { id: todo.id },
    });
  };

  const handleRemove = () => {
    dispatch({
      type: REMOVE_TODO,
      payload: { id: todo.id },
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -50 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 50 }}
      transition={{ duration: 0.3 }}
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: "10px",
        padding: "10px",
        border: "1px solid #ddd",
        borderRadius: "8px",
        backgroundColor: todo.completed ? "#e8f5e9" : "#fff",
        boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
        width: "600px",
      }}
    >
      <span
        style={{
          textDecoration: todo.completed ? "line-through" : "none",
          cursor: "pointer",
          flex: 1,
          color: todo.completed ? "#4caf50" : "#333",
        }}
        onClick={handleToggle}
      >
        {todo.task}
      </span>
      <div>
        {!todo.completed ? (
          <IconButton color="info" onClick={handleToggle}>
            <ClearIcon />
          </IconButton>
        ) : (
          <IconButton color="success" onClick={handleToggle}>
            <CheckCircleIcon />
          </IconButton>
        )}

        <IconButton color="error" onClick={handleRemove}>
          <DeleteIcon />
        </IconButton>
      </div>
    </motion.div>
  );
};

export default TodoItem;
