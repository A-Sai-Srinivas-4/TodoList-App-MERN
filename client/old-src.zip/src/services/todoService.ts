// src/services/todoService.ts
import api from './api';

// Define the Todo type
export interface Todo {
  id: string;
  task: string;
  completed: boolean;
}
// Explanation: Todo is a structure that holds an id, task, and completion status

// Get all todos
export const getTodos = async (): Promise<Todo[]> => {
  try {
    return await api.get('/todos'); // API call to get all todos
  } catch (error) {
    throw new Error('Error fetching todos');
  }
};
// Explanation: Get all todos from the server and return them as an array of Todo objects

// Add a new todo
export const addTodo = async (todo: Todo): Promise<Todo> => {
  try {
    return await api.post('/todos', todo); // API call to create a new todo
  } catch (error) {
    throw new Error('Error adding todo');
  }
};
// Explanation: Create a new todo on the server and return the created Todo object

// Remove a todo by ID
export const removeTodo = async (id: string): Promise<void> => {
  try {
    await api.delete(`/todos/${id}`); // API call to delete a todo by ID
  } catch (error) {
    throw new Error('Error removing todo');
  }
};
// Explanation: Delete a todo by ID from the server

// Toggle a todo's completion status
export const toggleTodo = async (id: string): Promise<Todo> => {
  try {
    return await api.patch(`/todos/${id}/toggle`); // API call to toggle completion status
  } catch (error) {
    throw new Error('Error toggling todo');
  }
};
// Explanation: Toggle a todo's completion status on the server and return the updated Todo object
